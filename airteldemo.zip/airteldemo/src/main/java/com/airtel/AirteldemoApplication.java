package com.airtel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirteldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirteldemoApplication.class, args);
	}

}
